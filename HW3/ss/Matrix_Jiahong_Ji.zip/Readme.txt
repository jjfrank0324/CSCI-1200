Matrix mutipication test;

Student name: Jiahong Ji(Frank)

RIN:661848836

Email:jij2@rpi.edu

Date: 12/4/2018

Compiling instuction: Make sure to compile both Matrix.cpp and the matrix_main.cpp at the same time. My complied file is called test.exe. You may use it if you want.

The Testingmuti() function in matrix_main.cpp include three specific test cases, which can show how the mutiplication function may perform in different cases. 
Specifically, the mutiplication operator is writed in the line 126~145 of Matrix.cpp. 
Matrix class also include some helper function which can help us visualize the matrix. Since the specific format of the input is unknown, the testing data for the matrix is directly written in Testingmuti() function in matrix_main.cpp. If the format of the input is known, I am able to add some helper function to read the given data and constuct matrix accordingly.(This is the thing I did a lot in CSCI-1100 and CSCI-1200). However, if you want to change the input data, you can simply change the data that I wrote in Testingmuti() function, and see how it goes.

The sample output is also included in the a pdf call sample.pdf.